from datasets import load_dataset
import os
# load cifar10 (only small portion for demonstration purposes)
import pruning_module
import time
import torch
import torch.autograd.profiler as profiler
from torch.profiler import profile, record_function, ProfilerActivity
from torch.quantization.qconfig import QConfig
from torch.quantization.fake_quantize import default_fused_act_fake_quant,default_fused_wt_fake_quant

os.environ["CUDA_VISIBLE_DEVICES"] = ""
torch.set_default_tensor_type(torch.FloatTensor)

device = 'cpu'
PATH = r'C:\Users\MVI_lab_2\PycharmProjects\vit_quantised'

train_ds, test_ds = load_dataset('cifar10', split=['train[:50000]', 'test[:10000]'])
# split up training into training + validation
splits = train_ds.train_test_split(test_size=0.03)
train_ds = splits['train']
val_ds = splits['test']

id2label = {id:label for id, label in enumerate(train_ds.features['label'].names)}
label2id = {label:id for id,label in id2label.items()}

from transformers import ViTFeatureExtractor

feature_extractor = ViTFeatureExtractor.from_pretrained("google/vit-base-patch16-224-in21k")

from torchvision.transforms import (CenterCrop,
                                    Compose,
                                    Normalize,
                                    RandomHorizontalFlip,
                                    RandomResizedCrop,
                                    Resize,
                                    ToTensor)

normalize = Normalize(mean=feature_extractor.image_mean, std=feature_extractor.image_std)
_train_transforms = Compose(
        [
            RandomResizedCrop(feature_extractor.size),
            RandomHorizontalFlip(),
            ToTensor(),
            normalize,
        ]
    )

_val_transforms = Compose(
        [
            Resize(feature_extractor.size),
            CenterCrop(feature_extractor.size),
            ToTensor(),
            normalize,
        ]
    )

def train_transforms(examples):
    examples['pixel_values'] = [_train_transforms(image.convert("RGB")) for image in examples['img']]
    return examples

def val_transforms(examples):
    examples['pixel_values'] = [_val_transforms(image.convert("RGB")) for image in examples['img']]
    return examples

train_ds.set_transform(train_transforms)
val_ds.set_transform(val_transforms)
test_ds.set_transform(val_transforms)

from transformers import ViTForImageClassification
from src.transformers.models.vit.modeling_vit import ViTLayer

Model = ViTForImageClassification.from_pretrained('google/vit-base-patch16-224-in21k',
                                                  num_labels=10,
                                                  id2label=id2label,
                                                  label2id=label2id)

from transformers import TrainingArguments, Trainer

metric_name = "accuracy"

epoch = 90
args = TrainingArguments(
    f"test-cifar-10",
    save_strategy="epoch",
    evaluation_strategy="epoch",
    learning_rate=2.5e-5,
    per_device_train_batch_size=64,
    per_device_eval_batch_size=64,
    num_train_epochs=epoch,
    weight_decay=0.01,
    load_best_model_at_end=True,
    metric_for_best_model=metric_name,
    logging_dir='logs',
    remove_unused_columns=False
)

from datasets import load_metric
import numpy as np

metric = load_metric("accuracy")

def compute_metrics(eval_pred):
    predictions, labels = eval_pred
    predictions = np.argmax(predictions, axis=1)
    return metric.compute(predictions=predictions, references=labels)


def print_model_size(mdl):
    torch.save(mdl.state_dict(), "tmp.pt")
    print("%.2f MB" % (os.path.getsize("tmp.pt") / 1e6))
    os.remove('tmp.pt')

from torch.utils.data import DataLoader
import torch

def collate_fn(examples):
    pixel_values = torch.stack([example["pixel_values"] for example in examples])
    labels = torch.tensor([example["label"] for example in examples])
    return {"pixel_values": pixel_values, "labels": labels}

from pruning_module import prune_model,fix_for_pruning

print('Model size without pruning and quantisation is -')
print_model_size(Model)


Model = prune_model(Model,example_inputs=torch.rand(10,3,224,224),non_pruning_layers=[],ratio=0.06)
print(Model)
Model = fix_for_pruning(170,Model)

Model.train()
Model = Model.cpu()

# Model.qconfig = torch.quantization.get_default_qat_qconfig('fbgemm')
Model.qconfig = QConfig(activation=default_fused_act_fake_quant, weight=default_fused_wt_fake_quant)

# Prepare the model for QAT. This inserts observers and fake_quants in
# the model that will observe weight and activation tensors during calibration.
torch.quantization.prepare_qat(Model,inplace=True)


# sample_input = torch.rand(10,3,224,224)
# with profile(activities=[ProfilerActivity.CPU], record_shapes=True) as prof:
#     Model(sample_input)
# print(prof.key_averages().table(sort_by="cpu_time_total", row_limit=15))
# eacfef

trainer = Trainer(
    Model,
    args,
    train_dataset=train_ds,
    eval_dataset=val_ds,
    data_collator=collate_fn,
    compute_metrics=compute_metrics,
    tokenizer=feature_extractor,
)
start_time = time.time()

trainer.train()
end_time = time.time()

print('Time taken for the training of the model - ',end_time-start_time)

Model.eval()

torch.quantization.convert(Model,inplace=True)

print('Model size without pruning, without quantisation is -')
print_model_size(Model)

torch.save({
            'epoch': epoch,
            'model_state_dict': Model.state_dict()
            } ,os.path.join(PATH,'model_weights_and_epoch.pth'))



