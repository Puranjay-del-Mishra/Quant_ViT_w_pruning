import torch
import torch.nn as nn
import torch_pruning as tp


def prune_model(model,example_inputs,non_pruning_layers,ratio,output_transform=None):
    prunable_module_type = (nn.BatchNorm2d,nn.Linear,nn.Conv2d)
    prunable_modules = []
    i = 1
    for m in model.modules():
        if isinstance(m, prunable_module_type) and i not in non_pruning_layers:
            prunable_modules.append(m)
        i += 1
    prunable_modules.pop()
    DG = tp.DependencyGraph().build_dependency(model, example_inputs=example_inputs, output_transform=output_transform)

    for layer_to_prune in prunable_modules:
        # select a layer
        if isinstance(layer_to_prune, nn.BatchNorm2d):
            prune_fn = tp.prune_batchnorm
        elif isinstance(layer_to_prune,nn.Linear):
            prune_fn = tp.prune_linear
        elif isinstance(layer_to_prune,nn.Conv2d):
            prune_fn = tp.prune_conv
        strategy = tp.strategy.L1Strategy()
        pruning_idxs = strategy(layer_to_prune.weight, amount=ratio)
        plan = DG.get_pruning_plan(layer_to_prune,prune_fn,pruning_idxs)
        plan.exec()

    return model


def fix_for_pruning(dim,model):
    model.vit.embeddings.cls_token = torch.nn.Parameter(torch.zeros(1, 1, dim))
    model.vit.embeddings.position_embeddings = torch.nn.Parameter(
        torch.zeros(1, model.vit.embeddings.patch_embeddings.num_patches + 1, dim))
    model.vit.layernorm = torch.nn.LayerNorm(dim, eps=model.vit.config.layer_norm_eps)
    for layer in model.vit.encoder.layer:
        layer.layernorm_before = torch.nn.LayerNorm(dim, eps=model.vit.config.layer_norm_eps, device='cpu')
        layer.layernorm_after = torch.nn.LayerNorm(dim, eps=model.vit.config.layer_norm_eps, device='cpu')
        layer.attention.attention.num_attention_heads = 9
        layer.attention.attention.attention_head_size = 71
        layer.attention.attention.all_head_size = 639 #ViTSelfOutput
    return model